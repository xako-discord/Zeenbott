const { Client, GatewayIntentBits, Collection } = require('discord.js');
const config = require('./config.json'); // Charger le fichier JSON

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

// Chargement des commandes
client.commands = new Collection();

try {
    const loadCommands = require('./handlers/loadCommands.js');
    loadCommands(client); // Charge les commandes
} catch (error) {
    console.error('Erreur lors du chargement des commandes :', error);
}

// Chargement des événements
try {
    const loadEvents = require('./handlers/loadEvents.js');
    loadEvents(client); // Charge les événements
} catch (error) {
    console.error('Erreur lors du chargement des événements :', error);
}

// Lancer le bot
client.once('ready', () => {
    console.log(`Connecté en tant que ${client.user.tag}`);
});

// Utilise le token depuis config.json
client.login(config.token)
    .catch(err => {
        console.error('Erreur lors de la connexion :', err);
    });
