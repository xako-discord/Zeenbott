const fs = require('fs');
const { ChannelType, ActionRowBuilder, StringSelectMenuBuilder, TextInputBuilder, ModalBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async run(client, interaction) {
        if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'config_select') {
                const selectedOption = interaction.values[0];

                if (selectedOption === 'arrivals') {
                    // Demander le canal pour les messages d'arrivée
                    const modal = new ModalBuilder()
                        .setCustomId('arrivals_modal')
                        .setTitle('Configurer les messages d\'arrivée');

                    const channelInput = new TextInputBuilder()
                        .setCustomId('arrival_channel')
                        .setLabel('ID du canal pour les messages d\'arrivée')
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('Entrez l\'ID du canal')
                        .setRequired(true);

                    const row = new ActionRowBuilder().addComponents(channelInput);
                    modal.addComponents(row);

                    await interaction.showModal(modal);
                }
            }
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'arrivals_modal') {
                const channelId = interaction.fields.getTextInputValue('arrival_channel');
                const channel = interaction.guild.channels.cache.get(channelId);

                if (!channel || channel.type !== ChannelType.GuildText) {
                    return interaction.reply({ content: 'ID de canal invalide. Veuillez réessayer.', ephemeral: true });
                }

                // Sauvegarder la configuration
                client.config.arrivalChannel = channelId;
                fs.writeFileSync('./config.json', JSON.stringify(client.config, null, 4));

                // Confirmation
                await interaction.reply({ content: `Les messages d'arrivée seront envoyés dans ${channel}.`, ephemeral: true });
            }
        }
    },
};
