const Discord = require("discord.js")
module.exports = {

    name: Discord.Events.ClientReady,
    
    async run(client) {

        client.application.commands.set(client.commands.map(command => command.data));

        console.log(`[✅] ${client.user.username} is online`)

        client.user.setActivity(`🟢 ZeenBase`, { type: Discord.ActivityType.Watching});

    }

}