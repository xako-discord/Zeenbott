module.exports = {
    name: 'messageCreate',
    run: (client, message) => {
        if (!message.author.bot && message.content.startsWith('+')) {
            const args = message.content.slice(1).trim().split(/ +/);
            const commandName = args.shift().toLowerCase();
            
            const command = client.commands.get(commandName);
            if (command) {
                try {
                    command.execute(client, message, args);
                } catch (error) {
                    console.error(error);
                    message.reply("Il y a eu un problème lors de l'exécution de cette commande !");
                }
            } else {
                message.reply("Commande non reconnue !");
            }
        }
    }
};
