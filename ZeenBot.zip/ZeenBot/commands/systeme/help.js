const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: {
        name: 'help',
        description: 'Affiche le système d\'aide du bot ZeenBot.',
    },
    async execute(client, message) {
        // URL de l'image en ligne
        const imageURL = 'https://media.discordapp.net/attachments/1277734203622162444/1315308416108986378/PDP_DISCORD_ZEENBASE.jpg?ex=6756efeb&is=67559e6b&hm=4f1d21289c0a9675ab1e092de73387fe4e676f7b3de0e2a54d2e75f2d4d27aa2&=&format=webp';

        // Embeds pour chaque page
        const embeds = [
            new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('Bienvenue dans le système d\'aide de ZeenBot')
                .setDescription('Ce bot permet de faire des recherches sur des utilisateurs, etc.')
                .addFields(
                    { name: '**VERSION**', value: '1.1 Beta', inline: false },
                    { name: '**Créateur**', value: '`.xako.` & `_nobodyknowme_`', inline: false },
                    { name: '**Préfix**', value: '`+`', inline: false }
                )
                .setThumbnail(imageURL)
                .setFooter({ text: 'Naviguez avec les boutons ci-dessous.' })
                .setTimestamp(),

            new EmbedBuilder()
                .setColor('#00cc99')
                .setTitle('Principale')
                .setDescription(
                    '`+site` - Permet d\'obtenir le site web de ZeenBot.\n\n**Statut** : Le site n\'est pas encore disponible.'
                )
                .setFooter({ text: 'Naviguez avec les boutons ci-dessous.' })
                .setTimestamp(),
        ];

        // Boutons pour chaque état
        const buttons = [
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('left')
                    .setLabel('⬅️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('right')
                    .setLabel('➡️')
                    .setStyle(ButtonStyle.Primary)
            ),
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('left')
                    .setLabel('⬅️')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('right')
                    .setLabel('➡️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)
            ),
        ];

        let currentPage = 0;

        // Envoyer la première page avec les boutons
        const sentMessage = await message.channel.send({
            embeds: [embeds[currentPage]],
            components: [buttons[currentPage]],
        });

        // Gestion des interactions
        const collector = sentMessage.createMessageComponentCollector({
            filter: (interaction) => interaction.user.id === message.author.id,
            time: 60000, // 1 minute
        });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'right' && currentPage < embeds.length - 1) {
                currentPage++;
            } else if (interaction.customId === 'left' && currentPage > 0) {
                currentPage--;
            }

            await interaction.update({
                embeds: [embeds[currentPage]],
                components: [buttons[currentPage]],
            });
        });

        collector.on('end', () => {
            // Désactiver les boutons après expiration du temps
            sentMessage.edit({
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('left')
                        .setLabel('⬅️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('right')
                        .setLabel('➡️')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true)
                )],
            });
        });
    },
};
