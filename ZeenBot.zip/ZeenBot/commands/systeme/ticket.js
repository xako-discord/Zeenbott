const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: {
        name: 'ticket',
        description: 'Crée un système de tickets pour le support.',
    },
    async execute(client, message) {
        // Embed pour le système de ticket
        const ticketEmbed = new EmbedBuilder()
            .setColor('#00b2ff')
            .setTitle('🎫 Système d\'aide de ZeenBase')
            .setDescription('Cliquez sur le bouton ci-dessous pour ouvrir un ticket.')
            .setFooter({ text: 'Système de support ZeenBase' })
            .setTimestamp();

        // Bouton pour créer un ticket
        const ticketButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('create_ticket')
                .setLabel('Ouvrir un Ticket')
                .setStyle(ButtonStyle.Primary)
        );

        // Envoyer le message initial
        const sentMessage = await message.channel.send({
            embeds: [ticketEmbed],
            components: [ticketButton],
        });

        // Gestion des interactions pour le bouton
        const collector = sentMessage.createMessageComponentCollector({
            filter: (interaction) => interaction.customId === 'create_ticket' && interaction.user.id === message.author.id,
            time: 60000, // 1 minute
        });

        collector.on('collect', async (interaction) => {
            // Créer un nouveau salon pour le ticket
            const guild = interaction.guild;
            const ticketChannel = await guild.channels.create({
                name: `ticket-${interaction.user.username}`,
                type: 0, // Salon texte
                permissionOverwrites: [
                    {
                        id: guild.roles.everyone.id,
                        deny: ['ViewChannel'], // Empêcher tout le monde de voir le ticket
                    },
                    {
                        id: interaction.user.id,
                        allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'], // Permettre à l'utilisateur de voir et écrire dans le salon
                    },
                ],
            });

            // Envoyer un message dans le salon du ticket
            const closeButton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('close_ticket')
                    .setLabel('Fermer le ticket')
                    .setStyle(ButtonStyle.Danger)
            );

            ticketChannel.send({
                content: `Bienvenue ${interaction.user}, un membre du staff vous assistera bientôt !`,
                embeds: [
                    new EmbedBuilder()
                        .setColor('#00b2ff')
                        .setTitle('🎫 Ticket créé')
                        .setDescription('Merci d\'avoir ouvert un ticket. Veuillez expliquer votre problème ci-dessous.')
                        .setFooter({ text: 'Système de support ZeenBase' })
                        .setTimestamp(),
                ],
                components: [closeButton], // Ajouter le bouton Fermer le ticket
            });

            await interaction.reply({
                content: `Votre ticket a été créé : ${ticketChannel}`,
                ephemeral: true, // Message visible uniquement par l'utilisateur
            });
        });

        collector.on('end', () => {
            // Désactiver les boutons après expiration du temps
            sentMessage.edit({
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('create_ticket')
                        .setLabel('Ouvrir un Ticket')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true)
                )],
            });
        });
    },

    // Gestion du bouton Fermer le ticket
    closeTicket: async (interaction) => {
        if (interaction.customId === 'close_ticket') {
            const channel = interaction.channel;

            if (channel.name.startsWith('ticket-')) {
                await interaction.reply({
                    content: 'Fermeture du ticket dans 5 secondes...',
                    ephemeral: true,
                });

                setTimeout(async () => {
                    await channel.delete();
                }, 5000);
            } else {
                interaction.reply({
                    content: "Ce salon n'est pas un ticket.",
                    ephemeral: true,
                });
            }
        }
    },
};
