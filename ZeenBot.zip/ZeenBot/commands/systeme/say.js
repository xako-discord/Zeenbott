// commands/systeme/say.js

module.exports = {
    data: {
        name: 'say',
        description: 'Fait dire quelque chose au bot.',
    },
    async execute(client, message, args) {
        // Vérifiez si l'utilisateur a fourni un message
        if (!args.length) {
            return message.reply("Veuillez spécifier un message à dire.");
        }

        // Rejoindre tous les arguments pour former le message
        const sayMessage = args.join(' ');

        // Envoyer le message dans le même canal
        try {
            await message.channel.send(sayMessage);
            // Optionnel : Supprimez le message de commande après l'envoi
            // message.delete();
        } catch (error) {
            console.error("Erreur lors de l'envoi du message :", error);
            message.channel.send("Une erreur est survenue lors de la tentative d'envoi du message.");
        }
    }
};
