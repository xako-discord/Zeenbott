// commands/systeme/ping.js

const { EmbedBuilder } = require('discord.js');

module.exports = {
    data: {
        name: 'ping',
        description: 'Affiche le ping du bot.'
    },
    async execute(client, message, args) { // Assurez-vous d'utiliser message ici
        const ping = client.ws.ping;

        const embed = new EmbedBuilder()
            .setColor('#00BFFF')
            .setTitle('Pong! 🏓')
            .setDescription(`Latence du bot : \`${ping} ms\``)
            .setTimestamp()
            .setFooter({ text: `Demandé par ${message.author.tag}`, iconURL: message.author.displayAvatarURL() }); // Utilisez message.author

        await message.channel.send({ embeds: [embed] });
    }
};
