// commands/systeme/clear.js

module.exports = {
    data: {
        name: 'clear',
        description: 'Supprime un certain nombre de messages.',
    },
    async execute(client, message, args) {
        // Vérifiez si l'utilisateur a fourni un nombre d'arguments
        if (!args[0]) {
            return message.reply("Veuillez spécifier le nombre de messages à supprimer.");
        }

        const amount = parseInt(args[0]);

        // Vérifiez que le nombre est valide
        if (isNaN(amount) || amount <= 0 || amount > 100) {
            return message.reply("Veuillez entrer un nombre valide entre 1 et 100.");
        }

        // Vérifiez si l'utilisateur a la permission de gérer les messages
        if (!message.member.permissions.has('MANAGE_MESSAGES')) {
            return message.reply("Vous n'avez pas la permission de gérer les messages.");
        }

        try {
            // Supprimez le message de commande et le nombre de messages spécifié
            const deletedMessages = await message.channel.bulkDelete(amount + 1, true);

            // Nous enlevons 1 au total pour le message de confirmation
            const confirmationCount = deletedMessages.size - 1;

            // Envoyez un message de confirmation
            const confirmationMessage = await message.channel.send(`${confirmationCount} message(s) supprimé(s).`);

            // Supprimez le message de confirmation après 3 secondes
            setTimeout(() => {
                confirmationMessage.delete();
            }, 3000);
        } catch (error) {
            console.error("Erreur lors de la suppression des messages :", error);
            message.channel.send("Une erreur est survenue lors de la tentative de suppression des messages.");
        }
    }
};
