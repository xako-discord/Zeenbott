const fs = require('fs');
const { Client, Collection, GatewayIntentBits, Events } = require('discord.js');
const { token, arrivalChannel, clientId, guildId } = require('./config.json');
const loadEvents = require('./handlers/loadEvents');
const loadCommands = require('./handlers/loadCommands');

// Créez une nouvelle instance de client
const client = new Client({ 
    intents: [
        GatewayIntentBits.Guilds, 
        GatewayIntentBits.GuildMessages, 
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers, // Intent pour les membres
        GatewayIntentBits.GuildMessageReactions // Intent pour les réactions
    ]
});

// Initialise les collections pour les commandes et les configurations
client.commands = new Collection();
client.config = { arrivalChannel };

// Fonction d'initialisation asynchrone
const init = async () => {
    // Charger les commandes
    await loadCommands(client); // Assurez-vous que loadCommands est une fonction asynchrone

    // Charger les événements
    await loadEvents(client); // Assurez-vous que loadEvents est une fonction asynchrone

    // Charger les commandes slash pour la première fois
    const { REST } = require('@discordjs/rest');
    const { Routes } = require('discord-api-types/v10'); // Mettez à jour vers v10 si nécessaire
    const rest = new REST({ version: '10' }).setToken(token);

    try {
        console.log('Début de la mise à jour des commandes (/) de l\'application.');

        const commandData = [];
        client.commands.forEach(command => commandData.push(command.data.toJSON()));

        await rest.put(
            Routes.applicationGuildCommands(clientId, guildId),
            { body: commandData },
        );

        console.log('Commandes (/) de l\'application rechargées avec succès.');
    } catch (error) {
        console.error('Erreur lors du rechargement des commandes :', error);
    }
};

// Événement de connexion
client.once('ready', () => {
    console.log(`Connecté en tant que ${client.user.tag}`);
});

// Gérer les interactions (boutons, commandes slash, etc.)
client.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isCommand()) {
        const command = client.commands.get(interaction.commandName);

        if (!command) return;

        try {
            await command.execute(interaction, client);
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'Une erreur s\'est produite lors de l\'exécution de cette commande.', ephemeral: true });
        }
    } else if (interaction.isButton()) {
        // Gestion des boutons
        if (interaction.customId === 'open_ticket') {
            try {
                // Vérifier si l'utilisateur a déjà un ticket
                const existingChannel = interaction.guild.channels.cache.find(
                    (channel) => 
                        channel.name === `ticket-${interaction.user.username}` && 
                        channel.type === 0 // GuildText
                );

                if (existingChannel) {
                    return interaction.reply({ content: 'Vous avez déjà un ticket ouvert !', ephemeral: true });
                }

                // Créer un salon pour le ticket
                const categoryId = '1315705127524634706'; // Remplacez par l'ID de votre catégorie
                const newChannel = await interaction.guild.channels.create({
                    name: `ticket-${interaction.user.username}`,
                    type: 0, // GuildText
                    parent: categoryId,
                    permissionOverwrites: [
                        {
                            id: interaction.guild.id,
                            deny: ['ViewChannel'],
                        },
                        {
                            id: interaction.user.id,
                            allow: ['ViewChannel', 'SendMessages'],
                        },
                        {
                            id: interaction.guild.members.me.id,
                            allow: ['ViewChannel', 'SendMessages'],
                        },
                    ],
                });

                // Envoyer un message dans le salon
                const ticketEmbed = {
                    color: 0x5865F2,
                    title: 'Ticket ZeenBase',
                    description: 'Un membre du staff vous répondra sous peu.\nCliquez sur le bouton ci-dessous pour fermer ce ticket.',
                    footer: { text: 'ZeenBase Help System' },
                    timestamp: new Date(),
                };

                const closeButton = {
                    type: 1, // ActionRow
                    components: [
                        {
                            type: 2, // Button
                            custom_id: 'close_ticket',
                            label: 'Fermer le ticket',
                            style: 4, // Danger (rouge)
                        },
                    ],
                };

                await newChannel.send({ embeds: [ticketEmbed], components: [closeButton] });

                interaction.reply({ content: `Votre ticket a été créé : ${newChannel}`, ephemeral: true });
            } catch (error) {
                console.error(error);
                interaction.reply({ content: "Une erreur s'est produite lors de la création du ticket.", ephemeral: true });
            }
        } else if (interaction.customId === 'close_ticket') {
            try {
                const channel = interaction.channel;

                if (channel.name.startsWith('ticket-')) {
                    await interaction.reply({ content: 'Fermeture du ticket dans 5 secondes...', ephemeral: true });

                    setTimeout(async () => {
                        await channel.delete();
                    }, 5000);
                } else {
                    interaction.reply({ content: "Ce salon n'est pas un ticket.", ephemeral: true });
                }
            } catch (error) {
                console.error(error);
                interaction.reply({ content: "Une erreur s'est produite lors de la fermeture du ticket.", ephemeral: true });
            }
        }
    }
});

// Connexion du client
client.login(token)
    .then(() => init()) // Exécutez l'initialisation après la connexion
    .catch(console.error);
