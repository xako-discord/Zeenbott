const fs = require('fs');
const path = require('path');

module.exports = async client => {
    let eventCount = 0;

    const eventDirs = fs.readdirSync('./events');
    for (const dir of eventDirs) {
        const dirPath = path.join(__dirname, '../events', dir);

        if (fs.statSync(dirPath).isDirectory()) {
            const eventFiles = fs.readdirSync(dirPath).filter(file => file.endsWith('.js'));

            for (const file of eventFiles) {
                const filePath = path.join(dirPath, file);
                try {
                    const event = require(filePath);

                    if (!event.name || typeof event.run !== 'function') {
                        console.error(`L'événement dans ${filePath} est invalide et ne sera pas chargé.`);
                        continue;
                    }

                    client.on(event.name, (...args) => event.run(client, ...args));
                    eventCount++;
                } catch (error) {
                    console.error(`Erreur lors du chargement de l'événement ${file}:`, error);
                }
            }
        }
    }

    console.log(`[✅] Chargé ${eventCount} événements.`);
};
