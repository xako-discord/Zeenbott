const fs = require('fs');
const path = require('path');

module.exports = async client => {
    let commandCount = 0;

    const commandsDir = fs.readdirSync('./commands/');
    
    for (const dir of commandsDir) {
        const dirPath = path.join(__dirname, '../commands', dir);

        if (fs.statSync(dirPath).isDirectory()) {
            const commandFiles = fs.readdirSync(dirPath).filter(file => file.endsWith('.js'));

            for (const file of commandFiles) {
                const filePath = path.join(dirPath, file);
                try {
                    const command = require(filePath);

                    // Vérification de la structure de la commande
                    if (!command.data || !command.data.name || typeof command.execute !== 'function') {
                        console.error(`La commande dans ${filePath} est invalide.`);
                        continue;
                    }

                    client.commands.set(command.data.name, command);
                    commandCount++;
                } catch (error) {
                    console.error(`Erreur lors du chargement de la commande ${file}:`, error);
                }
            }
        }
    }

    console.log(`[✅] Chargé ${commandCount} commandes.`);
};
